function rollDice(player) {
    const roll = Math.floor(Math.random() * 6) + 1;
    document.querySelector(`#player${player} .dice`).src = `dice${roll}.jpg`;
    document.querySelector(`#result${player}`).textContent = roll;
    checkWinner();
}

function checkWinner() {
    let results = [];
    for (let i = 1; i <= 4; i++) {
        results.push({
            player: i,
            roll: parseInt(document.querySelector(`#result${i}`).textContent)
        });
    }
    results.sort((a, b) => b.roll - a.roll);
    if (results[0].roll > results[1].roll) {
        document.getElementById('winner').textContent = `Player ${results[0].player} wins with a roll of ${results[0].roll}!`;
    } else {
        document.getElementById('winner').textContent = 'It\'s a tie!';
    }
}
